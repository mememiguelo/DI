numerodepalabras = int(input("Dígame cuántas palabras tiene la lista: "))

if numerodepalabras < 1:
    print("¡Imposible!")
else:
    lista = []
    for i in range(numerodepalabras):
        print("Dígame la palabra", str(i + 1) + ": ", end="")
        palabra = input()
        lista += [palabra]
    print("La lista creada es:", lista)

    listainversa = []
    for i in lista:
        listainversa = [i] + listainversa
    print("La lista inversa es:", listainversa)