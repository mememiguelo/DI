numerodepalabras = int(input("Dígame cuántas palabras tiene la lista: "))

if numerodepalabras < 1:
    print("¡Imposible!")
else:
    lista = []
    for i in range(numerodepalabras):
        print("Dígame la palabra", str(i + 1) + ": ", end="")
        palabra = input()
        lista += [palabra]
    print("La lista creada es:", lista)

    palabraparabuscar = input("Sustituir la palabra: ")
    palabraparasustituir = input("por la palabra: ")
    for i in range(len(lista)):
        if lista[i] == palabraparabuscar:
            lista[i] = palabraparasustituir
    print("La lista es ahora:", lista)